# Codebot 
Codebot is a simple JS-app to make you laugh 

## General Info 
User can choose a joke category to laugh about and gets random jokes from three different APIs 

## Languages 
HTML, CSS, JS

## Screenshots 
![Screenshot of project 1](./Codebot1.png)
![Screenshot of project 2](./Codebot2.png)